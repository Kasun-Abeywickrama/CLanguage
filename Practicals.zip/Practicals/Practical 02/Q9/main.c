#include<stdio.h>
int main(){
    int a;
    a=015 + 0x71 +5;
    printf("%d",a);
    return 0;
}

