#include<stdio.h>
int main(){
    int a=0,b=10;
    if(a=0){
         printf("true");
    }
    else{
         printf("false");
    }
    return 0;
}
