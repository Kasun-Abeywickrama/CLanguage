#include<stdio.h>
int main(){
    int i=1;
    i=2 + 2 * i++;
    printf("%d",i);
    return 0;
}
