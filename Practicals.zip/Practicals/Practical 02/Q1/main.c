#include <stdio.h>
#include <stdlib.h>

int main()
{
    int age;
    printf("HI, HOW OLD ARE YOU? ");
    scanf("%d",&age);

    printf("\n\n");
    printf("WELCOME (%d)\nLET'S BE FRIENDS!",age);
    return 0;
}
