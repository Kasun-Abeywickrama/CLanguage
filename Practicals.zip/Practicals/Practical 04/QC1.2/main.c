#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i=1;
    do{
      printf("%d\n",i);
      i++;
    }while(i<=100);
    return 0;
}
