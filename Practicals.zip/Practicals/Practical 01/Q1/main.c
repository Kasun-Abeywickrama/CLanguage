#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("Kasun Thiwanka\n");
    printf("Sripalee College");
    return 0;
}
